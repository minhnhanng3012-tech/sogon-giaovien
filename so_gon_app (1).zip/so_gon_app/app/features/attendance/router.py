from fastapi import APIRouter, Request, HTTPException
from fastapi.templating import Jinja2Templates

from app.core.config import TEMPLATES_DIR
from app.core.mock_data import CLASSES, STUDENTS_BY_CLASS, LESSON_FEEDBACK

router = APIRouter(prefix="/attendance", tags=["attendance"])
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


def _overall_rate(students):
    if not students:
        return 0
    rates = [int(s["attendance"].strip("%")) for s in students]
    return round(sum(rates) / len(rates))


@router.get("")
def attendance_list(request: Request):
    return templates.TemplateResponse(
        "attendance_list.html",
        {"request": request, "active_page": "attendance", "classes": CLASSES},
    )


@router.get("/{class_id}")
def attendance_class(request: Request, class_id: str):
    class_info = next((c for c in CLASSES if c["id"] == class_id), None)
    if not class_info:
        raise HTTPException(status_code=404, detail="Không tìm thấy lớp học")
    students = STUDENTS_BY_CLASS.get(class_id, [])
    feedback = [f for f in LESSON_FEEDBACK if f["className"].lower().replace(" ", "") in class_id]
    return templates.TemplateResponse(
        "attendance_class.html",
        {
            "request": request,
            "active_page": "attendance",
            "class_info": class_info,
            "students": students,
            "overall_rate": _overall_rate(students),
            "feedback": feedback,
        },
    )
