from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates

from app.core.config import TEMPLATES_DIR
from app.core.mock_data import REMINDERS, STUDENT_ALERTS

router = APIRouter(prefix="/academics", tags=["academics"])
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


@router.get("")
def academics(request: Request):
    return templates.TemplateResponse(
        "academics.html",
        {
            "request": request,
            "active_page": "academics",
            "reminders": REMINDERS,
            "alerts": STUDENT_ALERTS,
        },
    )
