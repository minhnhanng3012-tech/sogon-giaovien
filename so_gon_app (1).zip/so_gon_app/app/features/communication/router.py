from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates

from app.core.config import TEMPLATES_DIR
from app.core.mock_data import CLASSES, COMMUNICATION_LINKS

router = APIRouter(prefix="/communication", tags=["communication"])
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


@router.get("")
def communication(request: Request):
    return templates.TemplateResponse(
        "communication.html",
        {
            "request": request,
            "active_page": "communication",
            "classes": CLASSES,
            "links": COMMUNICATION_LINKS,
        },
    )
