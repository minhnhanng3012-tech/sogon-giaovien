from fastapi import APIRouter, Request, HTTPException
from fastapi.templating import Jinja2Templates

from app.core.config import TEMPLATES_DIR
from app.core.mock_data import CLASSES, STUDENTS_BY_CLASS

router = APIRouter(prefix="/students", tags=["students"])
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


@router.get("")
def students_list(request: Request):
    return templates.TemplateResponse(
        "students_list.html",
        {"request": request, "active_page": "students", "classes": CLASSES},
    )


@router.get("/{class_id}")
def students_by_class(request: Request, class_id: str):
    class_info = next((c for c in CLASSES if c["id"] == class_id), None)
    if not class_info:
        raise HTTPException(status_code=404, detail="Không tìm thấy lớp học")
    return templates.TemplateResponse(
        "students_class.html",
        {
            "request": request,
            "active_page": "students",
            "class_info": class_info,
            "students": STUDENTS_BY_CLASS.get(class_id, []),
        },
    )
