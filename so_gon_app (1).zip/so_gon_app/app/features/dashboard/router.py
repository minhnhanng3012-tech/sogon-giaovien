from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates

from app.core.config import TEMPLATES_DIR
from app.core.mock_data import TEACHER, METRICS, SCHEDULE, REMINDERS

router = APIRouter(tags=["dashboard"])
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


@router.get("/")
@router.get("/dashboard")
def dashboard(request: Request):
    return templates.TemplateResponse(
        "dashboard.html",
        {
            "request": request,
            "active_page": "dashboard",
            "teacher": TEACHER,
            "metrics": METRICS,
            "schedule": SCHEDULE,
            "reminders": REMINDERS,
        },
    )
