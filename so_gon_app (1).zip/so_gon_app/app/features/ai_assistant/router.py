import os

import httpx
from fastapi import APIRouter
from pydantic import BaseModel

from app.core.mock_data import STUDENT_ALERTS, METRICS, REMINDERS

router = APIRouter(prefix="/api/ai-assistant", tags=["ai_assistant"])

# The key is read from the environment, never hardcoded in source.
# Set it before starting the server, e.g.:
#   export GROQ_API_KEY="gsk_..."          (macOS/Linux)
#   set GROQ_API_KEY=gsk_...               (Windows cmd)
# or put GROQ_API_KEY=gsk_... in a local .env file that is NOT committed to git.
GROQ_API_KEY = os.environ.get("GROQ_API_KEY")
GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODEL = "llama-3.3-70b-versatile"

SYSTEM_PROMPT = (
    "Bạn là trợ lý AI của ứng dụng Sổ Gọn, hỗ trợ giáo viên Việt Nam quản lý lớp học. "
    "Trả lời ngắn gọn, thân thiện, bằng tiếng Việt. Dưới đây là dữ liệu hiện tại của giáo viên:\n"
    f"- Tỷ lệ điểm danh toàn trường: {METRICS['attendanceRate']['value']}\n"
    f"- Số học sinh hoạt động: {METRICS['activeStudents']['value']}\n"
    "- Cảnh báo học sinh: " + "; ".join(f"{a['name']} ({a['className']}): {a['detail']}" for a in STUDENT_ALERTS) + "\n"
    "- Nhắc nhở đang chờ: " + "; ".join(r["text"] for r in REMINDERS)
)


class ChatRequest(BaseModel):
    message: str


class ChatResponse(BaseModel):
    reply: str
    source: str  # "groq" or "fallback", useful for debugging in the UI if needed


def rule_based_reply(text: str) -> str:
    low = text.lower()
    if "điểm danh" in low or "chuyên cần" in low:
        return f"Tỷ lệ điểm danh hiện tại toàn trường là {METRICS['attendanceRate']['value']}."
    if "cảnh báo" in low or "yếu kém" in low or "tiến bộ" in low:
        lines = [f"- {a['name']} ({a['className']}): {a['detail']}" for a in STUDENT_ALERTS]
        return "Các cảnh báo học sinh gần đây:\n" + "\n".join(lines)
    if "lịch" in low:
        return "Cô/thầy có thể xem lịch giảng dạy chi tiết ở mục Trang Chủ, phần Lịch Học."
    return (
        "Em có thể hỗ trợ về: tình hình điểm danh, cảnh báo học sinh, "
        "hoặc lịch giảng dạy. Cô/thầy muốn hỏi về nội dung nào ạ?"
    )


@router.post("/chat", response_model=ChatResponse)
async def chat(payload: ChatRequest):
    """
    Calls Groq's chat completions API when GROQ_API_KEY is configured on the server.
    Falls back to a simple rule-based reply if the key is missing or the call fails,
    so the widget never breaks even without an API key set.
    """
    if not GROQ_API_KEY:
        return ChatResponse(reply=rule_based_reply(payload.message), source="fallback")

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(
                GROQ_URL,
                headers={"Authorization": f"Bearer {GROQ_API_KEY}"},
                json={
                    "model": GROQ_MODEL,
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": payload.message},
                    ],
                    "temperature": 0.4,
                    "max_tokens": 400,
                },
            )
            resp.raise_for_status()
            data = resp.json()
            reply = data["choices"][0]["message"]["content"].strip()
            return ChatResponse(reply=reply, source="groq")
    except Exception:
        # Network error, bad key, rate limit, etc. — degrade gracefully instead of 500ing.
        return ChatResponse(reply=rule_based_reply(payload.message), source="fallback")
