from fastapi import APIRouter, Request, HTTPException
from fastapi.templating import Jinja2Templates

from app.core.config import TEMPLATES_DIR
from app.core.mock_data import CLASSES, LIBRARY_FILES

router = APIRouter(prefix="/library", tags=["library"])
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


@router.get("")
def library_list(request: Request):
    file_counts = {cid: len(files) for cid, files in LIBRARY_FILES.items()}
    return templates.TemplateResponse(
        "library_list.html",
        {"request": request, "active_page": "library", "classes": CLASSES, "file_counts": file_counts},
    )


@router.get("/{class_id}")
def library_class(request: Request, class_id: str):
    class_info = next((c for c in CLASSES if c["id"] == class_id), None)
    if not class_info:
        raise HTTPException(status_code=404, detail="Không tìm thấy lớp học")
    return templates.TemplateResponse(
        "library_class.html",
        {
            "request": request,
            "active_page": "library",
            "class_info": class_info,
            "files": LIBRARY_FILES.get(class_id, []),
        },
    )
