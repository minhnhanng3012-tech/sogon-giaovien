document.addEventListener("DOMContentLoaded", () => {
  if (window.lucide) lucide.createIcons();

  // Live Vietnamese date in header
  const dateEl = document.getElementById("liveDateText");
  if (dateEl) {
    const now = new Date();
    dateEl.textContent = `Ngày ${now.getDate()} tháng ${now.getMonth() + 1} năm ${now.getFullYear()}`;
  }

  // AI widget toggle
  const aiToggle = document.getElementById("aiToggle");
  const aiPanel = document.getElementById("aiPanel");
  if (aiToggle && aiPanel) {
    aiToggle.addEventListener("click", () => aiPanel.classList.toggle("hidden"));
  }

  // AI widget mock reply
  const aiForm = document.getElementById("aiForm");
  if (aiForm) {
    aiForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const input = document.getElementById("aiInput");
      const messages = document.getElementById("aiMessages");
      const text = input.value.trim();
      if (!text) return;

      const userBubble = document.createElement("div");
      userBubble.className = "bg-olive text-white rounded-xl rounded-tr-none px-3 py-2 w-fit max-w-[85%] ml-auto";
      userBubble.textContent = text;
      messages.appendChild(userBubble);

      input.value = "";
      messages.scrollTop = messages.scrollHeight;

      fetch("/api/ai-assistant/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      })
        .then((r) => r.json())
        .then((data) => {
          const reply = document.createElement("div");
          reply.className = "bg-white rounded-xl rounded-tl-none px-3 py-2 w-fit max-w-[85%] shadow-sm whitespace-pre-line";
          reply.textContent = data.reply;
          messages.appendChild(reply);
          messages.scrollTop = messages.scrollHeight;
        })
        .catch(() => {
          const reply = document.createElement("div");
          reply.className = "bg-white rounded-xl rounded-tl-none px-3 py-2 w-fit max-w-[85%] shadow-sm";
          reply.textContent = "Xin lỗi, trợ lý AI hiện không phản hồi được. Vui lòng thử lại sau.";
          messages.appendChild(reply);
        });
    });
  }

  // Schedule range toggle (Today / Week / Month)
  document.querySelectorAll("[data-schedule-tab]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const range = btn.getAttribute("data-schedule-tab");
      document.querySelectorAll("[data-schedule-tab]").forEach((b) => {
        b.classList.remove("bg-olive", "text-white");
        b.classList.add("text-moss/70");
      });
      btn.classList.add("bg-olive", "text-white");
      btn.classList.remove("text-moss/70");

      document.querySelectorAll("[data-schedule-panel]").forEach((panel) => {
        panel.classList.toggle("hidden", panel.getAttribute("data-schedule-panel") !== range);
      });
    });
  });
});
