"""
In-memory mock/demo data for Sổ Gọn.
Replace with a real database layer (SQLModel/SQLAlchemy) in production.
"""

TEACHER = {
    "fullName": "Nguyễn Thị Lan",
    "age": 34,
    "workplace": "Trường THPT Chu Văn An",
    "subject": "Toán học",
    "avatarInitials": "L",
}

METRICS = {
    "attendanceRate": {"label": "Tỷ lệ điểm danh", "value": "92%", "delta": "+3% so với tháng trước", "icon": "clipboard-check"},
    "activeStudents": {"label": "Học sinh hoạt động", "value": "128", "delta": "+8 học sinh mới", "icon": "graduation-cap"},
    "totalClasses": {"label": "Tổng số lớp dạy", "value": "6", "delta": "Học kỳ 1", "icon": "school"},
    "missedClasses": {"label": "Tiết/Lớp nghỉ", "value": "2", "delta": "Tuần này", "icon": "calendar-x"},
}

CLASSES = [
    {"id": "10a1", "name": "Lớp 10A1", "studentCount": 42, "gvcn": "Nguyễn Thị Lan"},
    {"id": "10a2", "name": "Lớp 10A2", "studentCount": 40, "gvcn": "Trần Văn Bình"},
    {"id": "11a1", "name": "Lớp 11A1", "studentCount": 38, "gvcn": "Lê Thị Hoa"},
    {"id": "12a1", "name": "Lớp 12A1", "studentCount": 35, "gvcn": "Phạm Văn Đức"},
]

SCHEDULE = {
    "today": [
        {"name": "Toán học - Chương 3", "location": "Phòng A203", "participants": 42, "time": "07:00 - 07:45"},
        {"name": "Sinh hoạt lớp", "location": "Phòng A203", "participants": 42, "time": "08:00 - 08:45"},
        {"name": "Toán học - Lớp 10A2", "location": "Phòng B101", "participants": 40, "time": "09:00 - 09:45"},
    ],
    "week": [
        {"name": "Kiểm tra 15 phút - 10A1", "location": "Phòng A203", "participants": 42, "time": "Thứ 2, 07:00"},
        {"name": "Họp tổ chuyên môn", "location": "Phòng họp GV", "participants": 12, "time": "Thứ 4, 14:00"},
        {"name": "Ngoại khóa STEM", "location": "Sân trường", "participants": 120, "time": "Thứ 6, 09:00"},
    ],
    "month": [
        {"name": "Thi giữa kỳ 1", "location": "Toàn trường", "participants": 500, "time": "15/10 - 20/10"},
        {"name": "Họp phụ huynh", "location": "Hội trường lớn", "participants": 80, "time": "25/10"},
    ],
}

REMINDERS = [
    {"id": 1, "text": "Chuẩn bị đề kiểm tra 15 phút cho lớp 10A1", "pinned": True},
    {"id": 2, "text": "Gọi điện phụ huynh em Minh Anh về tình hình học tập", "pinned": True},
    {"id": 3, "text": "Nộp bảng điểm giữa kỳ trước thứ 6", "pinned": False},
]

STUDENT_ALERTS = [
    {"name": "Trần Minh Anh", "className": "10A1", "status": "yếu kém", "detail": "Môn Toán giảm từ 8.5 xuống 5.0"},
    {"name": "Lê Bảo Ngọc", "className": "10A2", "status": "tiến bộ", "detail": "Môn Văn tăng 2.0 điểm"},
    {"name": "Phạm Gia Hưng", "className": "11A1", "status": "yếu kém", "detail": "Điểm chuyên cần giảm còn 78%"},
    {"name": "Nguyễn Thảo Vy", "className": "12A1", "status": "tiến bộ", "detail": "Môn Anh văn tăng từ 6.5 lên 8.0"},
]

STUDENTS_BY_CLASS = {
    "10a1": [
        {"name": "Trần Minh Anh", "phone": "0901234567", "address": "Q. Cầu Giấy, Hà Nội", "gpa": 5.0, "attendance": "85%"},
        {"name": "Nguyễn Văn Hùng", "phone": "0912345678", "address": "Q. Đống Đa, Hà Nội", "gpa": 7.8, "attendance": "96%"},
        {"name": "Lê Thị Mai", "phone": "0923456789", "address": "Q. Thanh Xuân, Hà Nội", "gpa": 8.4, "attendance": "98%"},
    ],
    "10a2": [
        {"name": "Lê Bảo Ngọc", "phone": "0934567890", "address": "Q. Ba Đình, Hà Nội", "gpa": 8.1, "attendance": "94%"},
        {"name": "Phạm Đức Anh", "phone": "0945678901", "address": "Q. Hai Bà Trưng, Hà Nội", "gpa": 6.9, "attendance": "90%"},
    ],
    "11a1": [
        {"name": "Phạm Gia Hưng", "phone": "0956789012", "address": "Q. Tây Hồ, Hà Nội", "gpa": 6.2, "attendance": "78%"},
    ],
    "12a1": [
        {"name": "Nguyễn Thảo Vy", "phone": "0967890123", "address": "Q. Long Biên, Hà Nội", "gpa": 8.0, "attendance": "97%"},
    ],
}

COMMUNICATION_LINKS = {
    "10a1": {"zaloStudent": "https://zalo.me/g/example10a1hs", "zaloParent": "https://zalo.me/g/example10a1ph"},
    "10a2": {"zaloStudent": "https://zalo.me/g/example10a2hs", "zaloParent": "https://zalo.me/g/example10a2ph"},
    "11a1": {"zaloStudent": "https://zalo.me/g/example11a1hs", "zaloParent": "https://zalo.me/g/example11a1ph"},
    "12a1": {"zaloStudent": "https://zalo.me/g/example12a1hs", "zaloParent": "https://zalo.me/g/example12a1ph"},
}

LIBRARY_FILES = {
    "10a1": [
        {"name": "Điểm giữa kỳ - 10A1.xlsx", "type": "Giữa kỳ", "date": "2026-10-20"},
        {"name": "Điểm 15 phút - Tuần 5.csv", "type": "Kiểm tra 15p/miệng", "date": "2026-09-15"},
    ],
    "10a2": [
        {"name": "Điểm cuối kỳ - 10A2.xlsx", "type": "Cuối kỳ", "date": "2026-01-05"},
    ],
    "11a1": [],
    "12a1": [
        {"name": "Điểm giữa kỳ - 12A1.xlsx", "type": "Giữa kỳ", "date": "2026-10-18"},
    ],
}

LESSON_FEEDBACK = [
    {"className": "10A1", "date": "2026-09-25", "note": "Lớp học tập trung, làm bài tốt. 2 học sinh vắng có phép."},
    {"className": "10A2", "date": "2026-09-24", "note": "Một số em chưa làm bài tập về nhà, cần nhắc nhở."},
]
