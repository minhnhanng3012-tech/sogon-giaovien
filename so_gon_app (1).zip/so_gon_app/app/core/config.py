"""
Core configuration for Sổ Gọn.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

APP_NAME = "Sổ Gọn"
APP_TAGLINE = "Sổ Gọn - Sổ liên lạc gọn gàng cho giáo viên"

THEME = {
    "background": "#fefae0",
    "primary": "#606c38",
    "primaryDark": "#283618",
    "accent": "#dda15e",
    "accentDark": "#bc6c25",
}
