# Sổ Gọn — Ứng dụng Hỗ trợ Giáo viên & Quản lý Lớp học

Ứng dụng web full-stack (FastAPI + Jinja2 + Tailwind CSS) giúp giáo viên Việt Nam quản lý
điểm danh, học bạ, thông báo và tình hình học tập của học sinh trên một dashboard duy nhất.

## Chạy dự án

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```

Mở trình duyệt tại **http://127.0.0.1:8000**

## Bật trợ lý AI thật (Groq)

Trợ lý AI nổi hoạt động ngay cả khi chưa có API key (dùng câu trả lời dựng sẵn).
Để bật câu trả lời AI thật qua Groq, đặt biến môi trường **trước khi chạy server** —
KHÔNG dán API key trực tiếp vào mã nguồn hay commit vào git:

```bash
export GROQ_API_KEY="gsk_..."     # macOS/Linux, thay bằng key thật của bạn
uvicorn main:app --reload
```

Trên Windows (cmd): `set GROQ_API_KEY=gsk_...`
Hoặc tạo tệp `.env` (thêm `.env` vào `.gitignore`) và dùng `python-dotenv` để nạp biến này.

Nếu chưa đặt `GROQ_API_KEY`, endpoint `/api/ai-assistant/chat` tự động dùng câu trả lời
dựng sẵn (rule-based) — ứng dụng không bị lỗi.

⚠️ **Lưu ý bảo mật:** không bao giờ đặt API key trực tiếp trong mã nguồn phía frontend
(HTML/JS chạy trên trình duyệt), vì bất kỳ ai xem mã nguồn trang cũng có thể lấy được key.
Key chỉ nên nằm trên server (như cách triển khai ở trên).

## Cấu trúc thư mục

```
so_gon_app/
├── app/
│   ├── core/               # Config & dữ liệu mẫu (mock_data.py)
│   ├── features/
│   │   ├── dashboard/      # Trang chủ: metric cards, lịch dạy
│   │   ├── academics/      # Nhắc nhở giáo viên & cảnh báo học sinh
│   │   ├── students/       # Danh sách học sinh theo lớp
│   │   ├── attendance/     # Điểm danh & nhận xét sau tiết học
│   │   ├── library/        # Thư viện điểm số (Giữa kỳ/Cuối kỳ/15p)
│   │   ├── communication/  # Liên kết nhóm Zalo học sinh/phụ huynh
│   │   └── ai_assistant/   # API chat cho trợ lý AI nổi (mascot)
│   ├── static/              # CSS, JS, ảnh mascot
│   └── templates/           # Giao diện Jinja2 (tiếng Việt)
└── main.py                  # Điểm khởi chạy FastAPI
```

## Trạng thái hiện tại

Toàn bộ dữ liệu (`app/core/mock_data.py`) là **dữ liệu mẫu trong bộ nhớ** để demo giao diện
và luồng điều hướng. Để đưa vào sản xuất, cần:

1. Thay `mock_data.py` bằng một lớp truy cập cơ sở dữ liệu thật (khuyến nghị: SQLModel/SQLAlchemy + PostgreSQL).
2. Thêm xác thực người dùng (đăng nhập giáo viên) — hiện chưa có trong bản demo.
3. Kết nối endpoint `/api/ai-assistant/chat` (`app/features/ai_assistant/router.py`) tới một
   nhà cung cấp LLM thật, dùng nhận xét lớp học + điểm số + cảnh báo học sinh làm ngữ cảnh.
4. Thêm xử lý tải lên tệp thực sự cho module Thư Viện (hiện chỉ có giao diện chọn tệp).
5. Thêm các route ghi dữ liệu (POST/PUT) cho điểm danh, nhắc nhở, và nhận xét — hiện các
   form trên giao diện chưa gọi API lưu dữ liệu (chỉ có mock cho AI chat).

## Bảng màu

| Vai trò | Mã màu |
|---|---|
| Nền chính | `#fefae0` |
| Olive Green (chính) | `#606c38` |
| Dark Moss Green | `#283618` |
| Earth Yellow | `#dda15e` |
| Bronze/Tawny | `#bc6c25` |
