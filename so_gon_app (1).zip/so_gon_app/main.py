"""
Sổ Gọn - Vietnamese Teacher Assistance & Classroom Management Web App
Entry point: uvicorn main:app --reload
"""
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.core.config import APP_NAME, STATIC_DIR
from app.features.dashboard.router import router as dashboard_router
from app.features.academics.router import router as academics_router
from app.features.students.router import router as students_router
from app.features.attendance.router import router as attendance_router
from app.features.library.router import router as library_router
from app.features.communication.router import router as communication_router
from app.features.ai_assistant.router import router as ai_assistant_router

app = FastAPI(title=APP_NAME)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

app.include_router(dashboard_router)
app.include_router(academics_router)
app.include_router(students_router)
app.include_router(attendance_router)
app.include_router(library_router)
app.include_router(communication_router)
app.include_router(ai_assistant_router)
